
```
https://cloud.polyled.com {
    redir /.well-known/carddav /remote.php/dav/ 301
    redir /.well-known/caldav /remote.php/dav/ 301

    header {
      Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
      X-Frame-Options "SAMEORIGIN"
      X-Content-Type-Options "nosniff"
      Referrer-Policy "no-referrer-when-downgrade"
    }

    reverse_proxy 10.0.2.82:80

    handle_path /ocm-provider/* {
        reverse_proxy 10.0.2.82:80
    }


    handle_path /ocs-provider/* {
        reverse_proxy 10.0.2.82:80
    }

    handle_path /.well-known/carddav {
        redir /remote.php/dav 301
    }

    handle_path /.well-known/caldav {
        redir /remote.php/dav 301
    }

    handle_path /.well-known/webfinger {
        redir /index.php/.well-known/webfinger 301
    }

    handle_path /.well-known/nodeinfo {
        redir /index.php/.well-known/nodeinfo 301
    }

    tls internal {
        protocols tls1.2 tls1.3
    }
}
```