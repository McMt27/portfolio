```
proxmox.polyled.com {
    reverse_proxy 192.168.1.200:8006 {
        transport http {
        tls_insecure_skip_verify
        }
    }
}
```

Si tu me crois pas (mdr)

<https://forum.proxmox.com/threads/proxmox-ui-caddy-and-reverse-proxy.83198/>