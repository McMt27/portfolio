# Notice d'Installation et Configuration DNS (Bind9) - Projet PolyLED

Cette procédure détaille la mise en place du serveur DNS maître pour le domaine polyled.lan sur le site de Caen.

1. Pré-requis

    Disposer d'une machine sous Debian 12 ou Ubuntu Server 24.04.

    La machine doit avoir une IP statique (ex: 192.168.10.10).

    Accès privilèges sudo ou root.

2. Installation du paquet

Mise à jour des dépôts et installation de Bind9 :


sudo apt update
sudo apt install bind9 bind9utils

3. Configuration du Cache

Configuration des paramètres globaux pour permettre la résolution des noms Internet (rôle de cache) pour les clients.

Fichier : /etc/bind/named.conf.options
DNS Zone file

options {
    directory "/var/cache/bind";

    // Redirection vers les DNS publics (Google) pour l'accès internet
    forwarders {
        8.8.8.8;
        8.8.4.4;
    };

    dnssec-validation auto;
    listen-on-v6 { any; };
};

4. Déclaration de la Zone Locale

On déclare la zone polyled.lan et on indique au serveur où trouver le fichier de base de données.

Fichier : /etc/bind/named.conf.local
DNS Zone file

// Déclaration de la zone pour le site de Caen
zone "polyled.lan" {
    type master;
    // Emplacement spécifique du fichier de zone
    file "/var/cache/bind/db.polyled.lan";
};

5. Création du Fichier de Zone

Création du fichier de base de données contenant les enregistrements DNS.

5.2 Édition du fichier

Fichier : /var/cache/bind/db.polyled.lan

Remplacez le contenu par la configuration suivante (adaptez les IP selon votre plan d'adressage) :
DNS Zone file
````

$TTL    604800
@       IN      SOA     srv-polyled.polyled.lan. root.polyled.lan. (
                              2         ; Serial (à incrémenter à chaque modif)
                         604800         ; Refresh
                          86400         ; Retry
                        2419200         ; Expire
                         604800 )       ; Negative Cache TTL
;
; Serveurs de noms (NS)
@       IN      NS      srv-polyled.polyled.lan.

; Enregistrements A (IPv4)
@             IN      A       192.168.10.10
srv-polyled   IN      A       192.168.10.10  ; Le serveur DNS lui-même
router        IN      A       192.168.10.254 ; La passerelle
client-test   IN      A       192.168.10.50  ; Un poste client (exemple)
````
5.3 Permissions

Il est crucial de donner la propriété du fichier à l'utilisateur bind :
Bash

sudo chown bind:bind /var/cache/bind/db.polyled.lan

6. Vérification et Démarrage

6.1 Vérification de la syntaxe

Vérifier qu'il n'y a pas d'erreurs de syntaxe dans les fichiers :
Bash

# Vérifier la configuration globale
sudo named-checkconf

# Vérifier le fichier de zone spécifique
sudo named-checkzone polyled.lan /var/cache/bind/db.polyled.lan

Si la commande retourne "OK", la syntaxe est correcte.

6.2 Redémarrage du service

Bash

sudo systemctl restart bind9
sudo systemctl status bind9

7. Tests de validation

Depuis le serveur ou un client configuré :
Bash

# Tester la résolution locale
dig @192.168.10.10 srv-polyled.polyled.lan

# Tester la résolution externe (cache)
dig @192.168.10.10 google.com

4. Configuration du sous-réseau (Subnet)

On définit l'étendue des adresses à distribuer et les options (DNS, Passerelle).

Fichier : /etc/dhcp/dhcpd.conf

C'est ici que l'on fait le lien avec le DNS configuré précédemment. Ajoutez ce bloc à la fin du fichier :
Bash

# DHCP

# Configuration pour le LAN du site de Caen
# Le subnet DOIT correspondre à l'IP fixe du serveur (ici réseau 192.168.10.0)
subnet 192.168.10.0 netmask 255.255.255.0 {
    
    # Plage d'adresses IP à distribuer aux clients (Pool)
    range 192.168.10.100 192.168.10.200;

    # Masque de sous-réseau
    option subnet-mask 255.255.255.0;

    # Passerelle par défaut (Routeur de sortie vers le WAN)
    option routers 192.168.10.254;

    # Serveur DNS (L'IP de CE serveur, configuré juste avant)
    option domain-name-servers 192.168.10.10;

    # Nom de domaine local
    option domain-name "polyled.lan";
    
    # Durée du bail (en secondes)
    default-lease-time 600;
    max-lease-time 7200;
}

5. Validation et Démarrage

5.1 Vérification de la syntaxe

Avant de démarrer, on vérifie qu'il n'y a pas d'erreur de frappe (point-virgule manquant, accolade...).
Bash

sudo dhcpd -t -cf /etc/dhcp/dhcpd.conf

Si la commande ne renvoie pas d'erreur critique, la configuration est valide.

5.2 Démarrage du service

Bash

sudo systemctl restart isc-dhcp-server
sudo systemctl status isc-dhcp-server

Le statut doit être "active (running)".

6. Test Client (Recette)

Pour valider le fonctionnement, démarrez une machine cliente (Ubuntu Desktop ou une autre VM) connectée sur le même réseau interne.

    Mettre la carte réseau du client en mode "Automatique (DHCP)".

    Dans le terminal du client :
    Bash

# Forcer la demande d'IP
sudo dhclient -v -r
sudo dhclient -v

# Vérifier l'IP obtenue
ip a
# (Doit être entre 192.168.10.100 et .200)

# Vérifier le DNS
resolvectl status 
# (Doit indiquer 192.168.10.10)